package PageBeans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PersonalDetailsPOM {
	
WebDriver driver;
	
	@FindBy(id = "txtFirstName")
	WebElement firstName;
	
	@FindBy(id = "txtLastName")
	WebElement lastName;
	
	@FindBy(name = "Email")
	WebElement email;
	
	@FindBy(id = "txtPhone")
	WebElement phoneNo;
	
	@FindBy(id = "txtAddress1")
	WebElement address1;
	
	@FindBy(id = "txtAddress2")
	WebElement address2;
	
	@FindBy(name = "city")
	WebElement city;
	
	@FindBy(name = "state")
	WebElement state;
	
	
	@FindBy(xpath = "/html/body/form/table/tbody/tr[11]/td/a")
	WebElement submit;
	
	


	public PersonalDetailsPOM(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String sfirstName) {
		this.firstName.sendKeys(sfirstName);

}
	
	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String slastName) {
		this.lastName.sendKeys(slastName);

}
	
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String semail) {
		this.email.sendKeys(semail);

}
	public WebElement getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String sphoneNo) {
		this.phoneNo.sendKeys(sphoneNo);

}
	public WebElement getAddress1() {
		return address1;
	}

	public void setAddress1(String saddress1) {
		this.address1.sendKeys(saddress1);

}
	public WebElement getAddress2() {
		return address2;
	}

	public void setAddress2(String saddress2) {
		this.address2.sendKeys(saddress2);

}
	public WebElement getCity() {
		return city;
	}

	public void setCity(String scity) {
		this.city.sendKeys(scity);

}
	public WebElement getState() {
		return state;
	}

	public void setState(String sstate) {
		this.state.sendKeys(sstate);

}
	
	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		submit.click();

}
	
	


}
