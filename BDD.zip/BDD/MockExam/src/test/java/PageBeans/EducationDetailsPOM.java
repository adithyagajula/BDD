package PageBeans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationDetailsPOM {


    WebDriver driver;

    public EducationDetailsPOM(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
   
   
    @FindBy(name="graduation")
    WebElement grade;
   
   
    @FindBy(name="percentage")
    WebElement percentage;
    
   
    @FindBy(id="txtPassYear")
    WebElement year;
    
   
    @FindBy(name="projectName")
    WebElement project;
    
   
    @FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[1]")
    WebElement tech;
   
   
    @FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[3]")
    WebElement tech2;
    
    
    @FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[2]")
    WebElement tech1;
   
   
    @FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/input[4]")
    WebElement other;
   
    @FindBy(xpath="//*[@id=\"btnRegister\"]")
    WebElement register;
    
    
    public WebElement getRegister() {
		return register;
	}

	public void setRegister() {
		this.register.click();
    
}
	
	public WebElement getPercentage() {
		return percentage;
	}
	
	public void setPercentage(String spercentage) {
		this.percentage.sendKeys(spercentage);
		
	}
	public WebElement getYear() {
		return year;
	}
	
	public void setYear(String syear) {
		this.year.sendKeys(syear);
		
	}
	public WebElement getProject() {
		return project;
	}
	
	public void setProject(String sproject) {
		this.grade.sendKeys(sproject);
		
	}
	public WebElement getTech() {
		return tech;
	}
	
	public void setTech() {
		this.tech.click();
		
	}
	public WebElement getTech1() {
		return tech1;
	}
	
	public void setTech1( ) {
		this.tech1.click();
		
	}
	public WebElement getOther() {
		return other;
	}
	
	public void setOther( ) {
		this.other.click();
		
	}
	public WebElement getTech2() {
		return tech2;
	}
	
	public void setTech2( ) {
		this.tech2.click();
		
	}
	public WebElement getGrade() {
		return grade;
	}
	
	public void setGrade(String sgrade) {
		this.grade.sendKeys(sgrade);
		
	}
	
}