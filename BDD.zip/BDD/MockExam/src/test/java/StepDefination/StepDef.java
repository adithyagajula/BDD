package StepDefination;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;



import PageBeans.EducationDetailsPOM;
import PageBeans.PersonalDetailsPOM;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	WebDriver driver;
	PersonalDetailsPOM object;
	EducationDetailsPOM object1;
	
	@Given("^User is on personal Details Form page$")
	public void user_is_on_personal_Details_Form_page() throws Throwable {
	   
		//String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\GADITHYA\\\\Desktop\\\\chromedriver\\\\chromedriver.exe");
		driver = new ChromeDriver();
		object = new PersonalDetailsPOM(driver);
		driver.get("C:\\Users\\GADITHYA\\Downloads\\SET03\\WebPages\\PersonalDetails.html");
		
	
	}

	@Then("^Title should be \"([^\"]*)\"$")
	public void title_should_be(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		assertEquals("Personal Details", driver.getTitle());
	  
	}

	@When("^Next link is clicked without entering First Name or entered Name contains any other characters except alphabets$")
	public void next_link_is_clicked_without_entering_First_Name_or_entered_Name_contains_any_other_characters_except_alphabets() throws Throwable {
	   object.setFirstName("");
	   Thread.sleep(1000);
	   object.setSubmit();
	   
	}

	@Then("^error message should be displayed as \"([^\"]*)\"$")
	public void error_message_should_be_displayed_as(String arg1) throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();
	}
	
	@When("^Next link is clicked without entering Last Name or entered Name contains any other characters except alphabets$")
	public void next_link_is_clicked_without_entering_Last_Name_or_entered_Name_contains_any_other_characters_except_alphabets() throws Throwable {
	  object.setFirstName("adithya");
	  Thread.sleep(100);
	  object.setLastName("");
	  Thread.sleep(1000);
	  object.setSubmit();
	  
	}

	@When("^Next link is clicked without entering Email or entered Email is invalid like \"([^\"]*)\"$")
	public void next_link_is_clicked_without_entering_Email_or_entered_Email_is_invalid_like(String arg1) throws Throwable {
		  object.setLastName("gajula");
		  Thread.sleep(1000);
		  object.setEmail("");
		  object.setSubmit();
	}

	@When("^Next link is clicked without entering Phone number or entered phone number must start with (\\d+) or (\\d+) or (\\d+) or (\\d+) and length should be (\\d+)$")
	public void next_link_is_clicked_without_entering_Phone_number_or_entered_phone_number_must_start_with_or_or_or_and_length_should_be(int arg1, int arg2, int arg3, int arg4, int arg5) throws Throwable {
		  object.setEmail("gajulaadithya369@gmail.com");
		  Thread.sleep(1000);
		  object.setPhoneNo("");
		  object.setSubmit();
	}
	
	@When("^Next link is clicked without entering Addressline(\\d+) or entered Address contains any other characters except alphanumeric characters$")
	public void next_link_is_clicked_without_entering_Addressline_or_entered_Address_contains_any_other_characters_except_alphanumeric_characters(int arg1) throws Throwable {
		object.setPhoneNo("8179700938");
		Thread.sleep(1000);
		object.setAddress1("");
		object.setSubmit();
	}

	@When("^Next link is clicked without entering Addressline(\\d+) or entered Address contains only characters$")
	public void next_link_is_clicked_without_entering_Addressline_or_entered_Address_contains_only_characters(int arg1) throws Throwable {
		object.setAddress1("Hno-65");
		Thread.sleep(1000);
		object.setAddress2("");
		object.setSubmit();
	}

	

	
	@When("^Next link is clicked without selecting any City$")
	public void next_link_is_clicked_without_selecting_any_City() throws Throwable {
		  object.setAddress2("adithya street");
		  Thread.sleep(1000);
		  object.setCity("");
		  object.setSubmit();
	}

	@When("^Next link is clicked without selecting any State$")
	public void next_link_is_clicked_without_selecting_any_State() throws Throwable {
		Select drpcity=new Select(driver.findElement(By.name("city")));
		drpcity.selectByVisibleText("Hyderabad");
		Thread.sleep(1000);
		object.setState("");
		object.setSubmit();
	    
	}

	@When("^Next link is clicked after filling details$")
	public void next_link_is_clicked_after_filling_details() throws Throwable {
		Select drpstate=new Select(driver.findElement(By.name("state")));
		drpstate.selectByVisibleText("Telangana");
	    Thread.sleep(1000);
	    object.setSubmit();
	   
	}

	/*@Then("^It should redirect to Education details page$")
	public void it_should_redirect_to_Education_details_page() throws Throwable {
		assertEquals("Educational Details", driver.getTitle());
		
	}*/
	@Then("^message should be displayed as \"([^\"]*)\"$")
	public void message_should_be_displayed_as(String arg1) throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, arg1);
		driver.switchTo().alert().accept();
	}
	
	
	@When("^Register is clicked without selecting any Graduation$")
	public void register_is_clicked_without_selecting_any_Graduation() throws Throwable {
	Select drpgrad=new Select(driver.findElement(By.name("graduation")));
	drpgrad.selectByVisibleText("");
	Thread.sleep(1000);
	object1.setRegister();
	}

	}
	
	
	

