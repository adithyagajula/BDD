package StepDefinition;



import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.EmployeeRegistration;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	
	@Before(order=1)
	public void setup_step_env() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\GADITHYA\\\\\\\\Desktop\\\\\\\\chromedriver\\\\\\\\chromedriver.exe");
	}
	
	public static WebDriver driver;
	
	EmployeeRegistration empReg;
	
	@Given("^User launch the application and opens the registration page$")
	public void user_launch_the_application_and_opens_the_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver = new ChromeDriver();
	
		empReg=new EmployeeRegistration(driver);
		
		driver.get("C:\\Users\\GADITHYA\\Desktop\\SET A\\EmployeeRegistration.html");
		driver.manage().window().maximize();
	}

	@When("^User enter with different inputs$")
	public void user_enter_with_different_inputs() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   empReg.setEmpName("jack");
	   empReg.setEmpNum("1234566");
	}

	@When("^User enters with given inputs$")
	public void user_enters_with_given_inputs() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   driver.navigate().refresh();
	   empReg.setEmpName("Radhika");
	   empReg.setEmpNum("9666655522");
	   
	}

	
	
	
}
