package com.capgemini;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GithubLoginPage {
	WebDriver driver;
	public  GithubLoginPage(WebDriver driver) {
	
		this.driver=driver;
	}
	
	By username=By.id("login_field");
	   By Password=By.name("password");
	   By signin=By.name("commit");
	 
	   
	   
	   public WebElement Emaild()
	   {
		   return driver.findElement(username);
	   }
	         
	   public WebElement Password()
	   {
		   return driver.findElement(Password);
	   }
	   
	   public WebElement submit()
	   {
		   return driver.findElement(signin);
	   }
	   
	   

}
