package StepDefinition;



import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.Contact;
import PageBean.EmployeeRegistration;
import PageBean.Home;
import PageBean.Success;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	
	@Before(order=1)
	public void setup_step_env() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\GADITHYA\\\\\\\\Desktop\\\\\\\\chromedriver\\\\\\\\chromedriver.exe");
	}
	
	public static WebDriver driver;
	
	Home home;
	Contact contact;
	EmployeeRegistration empReg;
	Success success;
	
	@Given("^User launch the application and opens the home page$")
	public void user_launch_the_application_and_opens_the_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		driver = new ChromeDriver();
		home=new Home(driver);
		contact=new Contact(driver);
		empReg=new EmployeeRegistration(driver);
		success= new Success(driver);
		driver.get("C:\\Users\\GADITHYA\\Desktop\\SET A\\Home.html");
		driver.manage().window().maximize();
	    
	}

	@When("^User clicks on home header content$")
	public void user_clicks_on_home_header_content() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    home.setHome();
	}

	@Then("^Title should be displayed$")
	public void title_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		String title1 = "Home Page";
		assertEquals(title, title1);
	}

	@When("^User CLick on the Contact Us$")
	public void user_CLick_on_the_Contact_Us() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 contact.setContact();
	}

	@Then("^Title should be matched with the content Contact Us$")
	public void title_should_be_matched_with_the_content_Contact_Us() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		String title1 = "Contact Us";
		assertEquals(title, title1);
	}

	@When("^User Click on the Register link$")
	public void user_Click_on_the_Register_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().back();
		empReg.setRegister();
	}

	@Then("^Title should be matched with content Employee Registration Page$")
	public void title_should_be_matched_with_content_Employee_Registration_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		String title1 = "Employee Registration Page";
		assertEquals(title, title1);
	}

	@When("^User click the Submit button with out entering the Employee Name box$")
	public void user_click_the_Submit_button_with_out_entering_the_Employee_Name_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   empReg.setSubmit();
	}

	@Then("^Error message should be displayed as \"Please fill in the 'Your Employee Name' box\\.'$")
	public void error_message_should_be_displayed_as_Please_fill_in_the_Your_Employee_Name_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alt=driver.switchTo().alert();
		assertEquals("Please fill in the 'Your Employee Name' box.", alt.getText());
		alt.accept();
		Thread.sleep(1000);
		empReg.setEmpName("jack");
	}

	@When("^User click the Submit button with out entering the Employee Number box$")
	public void user_click_the_Submit_button_with_out_entering_the_Employee_Number_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 empReg.setSubmit();
	}

	@Then("^Error message should be displayed as 'Enter Employee Number'$")
	public void error_message_should_be_displayed_as_Enter_Employee_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alt=driver.switchTo().alert();
		assertEquals("Enter Employee Number", alt.getText());
		alt.accept();
		Thread.sleep(1000);
		//empReg.setEmpNum("123456");
	}

	@When("^User Enter the any  Character in Employee Number field$")
	public void user_Enter_the_any_Character_in_Employee_Number_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    empReg.setEmpNum("adi");
	}

	@Then("^Error message should be displayed as 'Enter Number'$")
	public void error_message_should_be_displayed_as_Enter_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alt=driver.switchTo().alert();
		assertEquals("Enter Number", alt.getText());
		alt.accept();
		Thread.sleep(1000);
		empReg.setEmpNum("123456");
	}

	@When("^User Enter the any  Character in Contact Number field$")
	public void user_Enter_the_any_Character_in_Contact_Number_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   empReg.setPhoneNum("as");;
	}

	@When("^User click the Submit button with out selecting Job Location$")
	public void user_click_the_Submit_button_with_out_selecting_Job_Location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		empReg.setSubmit();
	}

	@Then("^Error message should be displayed as 'Select your Job Location'$")
	public void error_message_should_be_displayed_as_Select_your_Job_Location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alt=driver.switchTo().alert();
		assertEquals("Select your Job Location", alt.getText());
		alt.accept();
		Thread.sleep(1000);
		empReg.getLocation1().click();;
	}

	@When("^User click the submit button with entering invalid email address$")
	public void user_click_the_submit_button_with_entering_invalid_email_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    empReg.setEmail("jack");
	    empReg.setSubmit();
	    
	}

	@Then("^Error message should be displayed as 'You have entered an invalid email address!'$")
	public void error_message_should_be_displayed_as_You_have_entered_an_invalid_email_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		// Write code here that turns the phrase above into concrete actions
				Alert alt=driver.switchTo().alert();
				assertEquals("You have entered an invalid email address!", alt.getText());
				alt.accept();
				Thread.sleep(1000);
	}

	@When("^User enters the all the values and click on the submit button$")
	public void user_enters_the_all_the_values_and_click_on_the_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    empReg.setPhoneNum("8888444222");
	    empReg.setEmail("jack@gmail.com");
	    empReg.setAddress("bangolore");
	    empReg.setSubmit();
	}

	@Then("^Title should be matched$")
	public void title_should_be_matched() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		String title1 = "Confimation Page";
		assertEquals(title, title1);
	}
	
	
}
