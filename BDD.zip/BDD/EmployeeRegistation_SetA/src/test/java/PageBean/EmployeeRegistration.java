package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmployeeRegistration {


	WebDriver driver;

	public EmployeeRegistration(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="/html/body/div/header/ul/li[2]/a")
	WebElement register;
	
	public WebElement getRegister() {
		return register;
	}
	public void setRegister() {
		this.register.click();
	}
	
	@FindBy(name="emp_name")
	WebElement empName;
	
	public WebElement getEmpName() {
		return empName;
	}
	public void setEmpName(String sname) {
		this.empName.sendKeys(sname);;
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td/p/input[1]")
	WebElement submit;
	
	public WebElement getSubmit() {
		return submit;
	}
	public void setSubmit() {
		this.submit.click();
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[3]/td[2]/input")
	WebElement empNum;
	
	public WebElement getEmpNum() {
		return empNum;
	}
	public void setEmpNum(String snum) {
		this.empNum.sendKeys(snum);;
	}
	
	@FindBy(name="txtFName1")
	WebElement phoneNum;
	
	public WebElement getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String sphonenum) {
		this.phoneNum.sendKeys(sphonenum);;
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/select/option[1]")
	WebElement location;
	
	public WebElement getLocation() {
		return location;
	}
	public void setLocation(WebElement location) {
		this.location=location;
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/select/option[3]")
	WebElement location1;
	
	public WebElement getLocation1() {
		return location1;
	}
	public void setLocation1(WebElement location1) {
		this.location1=location1;
	}
	
	@FindBy(name="email_id")
	WebElement email;
	
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String semail) {
		this.email.sendKeys(semail);;
	}
	
	@FindBy(name="S2")
	WebElement address;
	
	public WebElement getAddress() {
		return address;
	}
	public void setAddress(String saddress) {
		this.address.sendKeys(saddress);;
	}
	
}
