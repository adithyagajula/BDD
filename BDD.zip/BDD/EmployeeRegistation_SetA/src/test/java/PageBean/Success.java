package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Success {


	WebDriver driver;

	public Success(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
}
