package junitTest;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserSteps {
	public static void main(String[] args) {
		
	
	}
	@Before(order=1)
	public void setup_step_env() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\GADITHYA\\Desktop\\chromedriver\\chromedriver.exe");
	}
	
	public static WebDriver driver;
	
	
//	@Given("^Open Amazon$")
//	public void open_Amazon() throws Throwable {
//		driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fcss%2Fhomepage.html%3Fie%3DUTF8%26%252AVersion%252A%3D1%26%252Aentries%252A%3D0");
//		driver.manage().window().maximize();
//	}
//
//	@When("^User enters valid username and password$")
//	public void user_enters_valid_username() throws Throwable {
//		WebElement searchelement = driver.findElement(By.name("email"));
//	    searchelement.sendKeys("adithyagajula369@gmail.com");
//	    searchelement.submit();
//	    WebElement searchelement2 = driver.findElement(By.name("password"));
//	    searchelement2.sendKeys("adithya369");
//	    searchelement2.submit();
//	}
//
//	
//	@Then("^User logged in$")
//	public void user_logged_in() throws Throwable {
//		assertEquals("Your Account",driver.getTitle());
//	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
//	}
	
	
	@Given("^Open Amazon$")
	public void open_Amazon() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fcss%2Fhomepage.html%3Fie%3DUTF8%26%252AVersion%252A%3D1%26%252Aentries%252A%3D0");
		//driver.manage().window().maximize();
	    
	}

	@When("^User enters valid username and password$")
	public void user_enters_valid_username_and_password() throws Throwable {
		WebElement searchelement = driver.findElement(By.name("email"));
	    searchelement.sendKeys("adithyagajula369@gmail.com");
	    searchelement.submit();
	    WebElement searchelement2 = driver.findElement(By.name("password"));
	    searchelement2.sendKeys("adithya369");
	    searchelement2.submit();
	}

	@Then("^User logged in$")
	public void user_logged_in() throws Throwable {
		assertEquals("Your Account",driver.getTitle());
	}


}
	
