package com.capgemini;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleDemo {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\GADITHYA\\Desktop\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.google.com/");
		
		//WebElement searchelement = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		//WebElement searchelement = driver.findElement(By.id("tsf"));
		/*WebElement searchelement = driver.findElement(By.name("q"));
		searchelement.sendKeys("Capgemini");
		searchelement.submit();*/
		
		WebElement images=driver.findElement(By.linkText("Images"));
		images.click();
	}

}
