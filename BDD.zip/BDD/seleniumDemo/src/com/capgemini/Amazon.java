package com.capgemini;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\GADITHYA\\Desktop\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		/*driver.get("https://www.amazon.in/?ie=UTF8&ext_vrnc=hi&tag=googinabkvernac-21&ascsubtag=_k_EAIaIQobChMItveArduJ5gIV1ByPCh1KSwnDEAAYASAAEgIYd_D_BwE_k_&ext_vrnc=hi&gclid=EAIaIQobChMItveArduJ5gIV1ByPCh1KSwnDEAAYASAAEgIYd_D_BwE");
		driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("iphone xr 128gb");
		driver.findElement(By.id("huc-v2-order-row-with-divider")).click();*/
		driver.get("http://www.google.com/");
		WebElement searchelement = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		searchelement.sendKeys("Amazon");
		searchelement.submit();
		
		
		
		WebElement searchelement2 = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div[1]/div/div/div[1]/a/h3/span"));
		searchelement2.click();
		
		WebElement searchelement3 = driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
		searchelement3.sendKeys("iphone xr 128gb");
		searchelement3.submit();
		
		String oldTab = driver.getWindowHandle();
        WebElement searchelement4=driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span"));           
        searchelement4.click();  
        ArrayList<String> newTab = new ArrayList<String>(driver.getWindowHandles());
           newTab.remove(oldTab);
           // change focus to new tab
           driver.switchTo().window(newTab.get(0));
		
		
//		
	WebElement searchelement5 = driver.findElement(By.xpath("//*[@id=\"buy-now-button\"]"));
	searchelement5.click();
	

	
	WebElement searchelement6 = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
	searchelement6.sendKeys("adithyagajula369@gmail.com");
	WebElement searchelement7 = driver.findElement(By.xpath("//*[@id=\"continue\"]"));
	searchelement7.click();
	
	WebElement searchelement8 = driver.findElement(By.xpath("//*[@id=\"ap_password\"]"));
	searchelement8.sendKeys("adithya369");
	
	WebElement searchelement9 = driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]"));
	searchelement9.click();
	
	
	}
}
